<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

function getAppSettings() {
    $settings = null;
    try {
        $settings = DB::table('app_settings')->where('id', 1)->first();
    } catch (\Exception $e) {}

    if (!$settings) {
        $settings = (object)[
            'app_name' => 'Rainbow Travels & Tours',
            'developer' => 'Rainbow Travels',
            'category' => 'Travel',
            'tags' => 'Visa Services · Tours',
            'app_icon' => '',
            'rating_score' => '4.8',
            'reviews_count' => '5K reviews',
            'downloads_count' => '10K+',
            'content_rating' => 'Rated for 3+',
            'updated_date' => 'Oct 20, 2023',
            'description' => 'Journey Beyond Boundaries with Rainbow Travels & Tours.',
            'release_notes' => '• Improved visa tracking\r\n• Bug fixes',
            'screenshots' => '[]',
            'apk_url' => '/apk/app-release.apk',
            'active_theme' => 'travel',
            'home_banner' => '',
            'inner_banner' => '',
            'phone' => '+92 300 123 4567',
            'email' => 'info@visabook.com',
            'address' => '123 Travel Street, Islamabad',
            'footer_text' => 'All rights reserved.'
        ];
    }
    return $settings;
}

Route::get('/', function () {
    $settings = getAppSettings();
    $theme = $settings->active_theme ?? 'travel';

    $countries = [];
    $categories = [];
    try {
        $countries = DB::table('app_countries')->orderBy('name', 'asc')->get();
        $categoryQuery = DB::table('app_categories')->orderBy('id', 'desc');
        if (Schema::hasColumn('app_categories', 'country_id')) {
            $categoryQuery->leftJoin('app_countries', 'app_countries.id', '=', 'app_categories.country_id')
                ->select('app_categories.*', 'app_countries.name as country_name');
        }
        $categories = $categoryQuery->get();
    } catch (\Exception $e) {}

    if ($theme === 'playstore') {
        return view('frontend.index', compact('settings', 'countries'));
    }

    if ($theme === 'landing') {
        return view('index', compact('settings', 'countries'));
    }

    return view('frontend.travel', compact('settings', 'countries', 'categories'));
});

// Travel App Routes
Route::get('/dashboard', function () {
    $settings = getAppSettings();
    return view('frontend.travel_dashboard', compact('settings'));
})->name('travel.dashboard');

Route::match(['get', 'post'], '/verify', [AdminController::class, 'checkVisaStatus'])->name('travel.verify');
Route::get('/verify/visa-document/{id}', [AdminController::class, 'downloadIssuedVisaDocument'])
    ->middleware('signed')
    ->whereNumber('id')
    ->name('travel.visa_document.download');

Route::get('/apply/success/{id}', [AdminController::class, 'applicationSuccess'])->name('travel.apply.success');
Route::post('/apply/success/{id}/payment-receipt', [AdminController::class, 'uploadPaymentReceipt'])->name('travel.apply.payment_receipt');
Route::post('/apply/success/{id}/flight-ticket', [AdminController::class, 'submitFlightTicketRequest'])->name('travel.apply.flight_ticket');

Route::get('/apply', function () {
    $settings = getAppSettings();
    $countries = [];
    $nationalities = [];
    $categories = [];
    $professions = [];
    $jobs = [];
    try {
        $countries = DB::table('app_countries')->orderBy('name', 'asc')->get();
        $nationalities = DB::table('app_nationalities')->orderBy('name', 'asc')->get();
        $categories = DB::table('app_categories')->orderBy('id', 'desc')->get();
        $professions = DB::table('app_profession_job_titles')->where('type', 'profession')->orderBy('name')->get();
        $jobs = DB::table('app_jobs')->where('status', 'Active')->orderByDesc('id')->get();
    } catch (\Exception $e) {}
    return view('frontend.travel_apply', compact('settings', 'countries', 'nationalities', 'categories', 'professions', 'jobs'));
})->name('travel.apply');

Route::post('/apply', [AdminController::class, 'submitVisaRequest'])->name('travel.apply.post');

Route::get('/about', function () {
    $settings = getAppSettings();
    return view('frontend.travel_about', compact('settings'));
})->name('travel.about');

Route::get('/contact', function () {
    $settings = getAppSettings();
    return view('frontend.travel_contact', compact('settings'));
})->name('travel.contact');

Route::get('/jobs', [AdminController::class, 'publicJobs'])->name('jobs.index');

// API for dynamic visa types
Route::get('/api/visa-types/{category_id}', [AdminController::class, 'getVisaTypesByCategory']);

// Admin Login Routes
Route::get('/admin/login', [AdminController::class, 'showLogin'])->name('admin.login');
Route::post('/admin/login', [AdminController::class, 'login'])->name('admin.login.post');

// Protected Admin Routes
Route::middleware(['admin.auth'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::post('/admin/logout', [AdminController::class, 'logout'])->name('admin.logout');

    // Job management pages
    Route::get('/admin/jobs', [AdminController::class, 'jobsIndex'])->name('admin.jobs.index');
    Route::get('/admin/jobs/create', [AdminController::class, 'createJob'])->name('admin.jobs.create');
    Route::post('/admin/jobs/{id}/duplicate', [AdminController::class, 'duplicateJob'])->whereNumber('id')->name('admin.jobs.duplicate');
    Route::get('/admin/jobs/{id}/edit', [AdminController::class, 'editJob'])->name('admin.jobs.edit');
    Route::put('/admin/jobs/{id}', [AdminController::class, 'updateJob'])->name('admin.jobs.update');

    // Catalog management pages
    Route::get('/admin/catalog', [AdminController::class, 'catalogIndex'])->name('admin.catalog.index');
    Route::get('/admin/catalog/{type}/add', [AdminController::class, 'createCatalogItem'])->name('admin.catalog.create');
    Route::get('/admin/catalog/{type}/{id}/edit', [AdminController::class, 'editCatalogItem'])->whereNumber('id')->name('admin.catalog.edit');
    Route::put('/admin/catalog/{type}/{id}', [AdminController::class, 'updateCatalogItem'])->whereNumber('id')->name('admin.catalog.update');
    Route::post('/admin/catalog/{type}', [AdminController::class, 'storeCatalogItem'])->name('admin.catalog.store');
    Route::delete('/admin/catalog/{type}/{id}', [AdminController::class, 'deleteCatalogItem'])->whereNumber('id')->name('admin.catalog.delete');

    // Profession and job-title options
    Route::get('/admin/profession-job-titles', [AdminController::class, 'professionJobTitlesIndex'])->name('admin.profession_job_titles.index');
    Route::post('/admin/profession-job-titles', [AdminController::class, 'addProfessionJobTitle'])->name('admin.profession_job_titles.add');
    Route::delete('/admin/profession-job-titles/{id}', [AdminController::class, 'deleteProfessionJobTitle'])->whereNumber('id')->name('admin.profession_job_titles.delete');

    // Play Store Settings API
    Route::post('/admin/settings/update', [AdminController::class, 'updateSettings'])->name('admin.settings.update');
    Route::post('/admin/settings/remove-screenshot', [AdminController::class, 'removeScreenshot'])->name('admin.settings.remove_screenshot');

    // APK Management API
    Route::post('/admin/apk/update-url', [AdminController::class, 'updateApkUrl'])->name('admin.apk.update_url');
    Route::post('/admin/apk/upload', [AdminController::class, 'uploadApk'])->name('admin.apk.upload');

    // Country Management API
    Route::post('/admin/countries/add', [AdminController::class, 'addCountry'])->name('admin.countries.add');
    Route::post('/admin/countries/delete', [AdminController::class, 'deleteCountry'])->name('admin.countries.delete');
    Route::post('/admin/nationalities/add', [AdminController::class, 'addNationality'])->name('admin.nationalities.add');
    Route::post('/admin/nationalities/delete', [AdminController::class, 'deleteNationality'])->name('admin.nationalities.delete');
    Route::post('/admin/nationalities/airports/add', [AdminController::class, 'addNationalityAirports'])->name('admin.nationalities.airports.add');
    Route::post('/admin/airports/add', [AdminController::class, 'addAirport'])->name('admin.airports.add');
    Route::post('/admin/airports/delete', [AdminController::class, 'deleteAirport'])->name('admin.airports.delete');

    // Category Management API
    Route::post('/admin/categories/add', [AdminController::class, 'addCategory'])->name('admin.categories.add');
    Route::post('/admin/categories/delete', [AdminController::class, 'deleteCategory'])->name('admin.categories.delete');

    // Visa Type Management API
    Route::post('/admin/visa-types/add', [AdminController::class, 'addVisaType'])->name('admin.visa_types.add');
    Route::post('/admin/visa-types/delete', [AdminController::class, 'deleteVisaType'])->name('admin.visa_types.delete');

    // Job Management API
    Route::post('/admin/jobs/add', [AdminController::class, 'addJob'])->name('admin.jobs.add');
    Route::post('/admin/jobs/delete', [AdminController::class, 'deleteJob'])->name('admin.jobs.delete');

    // Bank Account Management API
    Route::post('/admin/bank-accounts/add', [AdminController::class, 'addBankAccount'])->name('admin.bank_accounts.add');
    Route::post('/admin/bank-accounts/delete', [AdminController::class, 'deleteBankAccount'])->name('admin.bank_accounts.delete');
    Route::get('/admin/bank-accounts/{id}/edit', [AdminController::class, 'editBankAccount'])->name('admin.bank_accounts.edit');
    Route::put('/admin/bank-accounts/{id}', [AdminController::class, 'updateBankAccount'])->name('admin.bank_accounts.update');

    // Requests Management
    Route::post('/admin/requests/delete', [AdminController::class, 'deleteRequest'])->name('admin.requests.delete');
    Route::get('/admin/requests/{id}/pdf', [AdminController::class, 'requestApplicationPdf'])->whereNumber('id')->name('admin.requests.pdf');
    Route::get('/admin/requests/{id}/visa-document', [AdminController::class, 'downloadIssuedVisaDocument'])->whereNumber('id')->name('admin.requests.visa_document');
    Route::get('/admin/requests/{id}/edit', [AdminController::class, 'editRequest'])->name('admin.requests.edit');
    Route::post('/admin/requests/update-status', [AdminController::class, 'updateRequestStatus'])->name('admin.requests.update_status');
    Route::post('/admin/requests/{id}', [AdminController::class, 'updateRequest'])->whereNumber('id')->name('admin.requests.update');
    Route::post('/admin/ticket-requests/update-status', [AdminController::class, 'updateTicketRequestStatus'])->name('admin.ticket_requests.update_status');

    // Security API
    Route::post('/admin/password/update', [AdminController::class, 'updatePassword'])->name('admin.password.update');
});
